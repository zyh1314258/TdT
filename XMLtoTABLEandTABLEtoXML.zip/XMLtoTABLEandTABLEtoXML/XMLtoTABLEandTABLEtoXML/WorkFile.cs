﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
namespace XMLtoTABLEandTABLEtoXML
{
    class WorkFile
    {
        // DataSet ds = new DataSet();
        //
        public List<WorkItem> Read(string path)
        {

            List<WorkItem> list = new List<WorkItem>();

            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(path);

            XmlNodeList workItemNodes = xmldoc.DocumentElement.ChildNodes;
            foreach (XmlNode workItemNode in workItemNodes)   //遍历books的节点
            {
                XmlNodeList workItemdetails = workItemNode.ChildNodes;

                WorkItem workItem = new WorkItem();

                foreach (XmlNode nodeDetail in workItemdetails)
                {

                    if (nodeDetail.Name == "priority")
                    {

                        workItem.Priority = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "classification")
                    {
                        workItem.Classification = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "detail")
                    {
                        workItem.Detail = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "method")
                    {
                        workItem.Method = nodeDetail.InnerText;

                    }
                    else if (nodeDetail.Name == "enclosure")
                    {

                        workItem.Enclosure = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "logger")
                    {
                        workItem.Logger = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "finishtime")
                    {
                        workItem.FinishTime = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "maker")
                    {
                        workItem.Maker = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "state")
                    {
                        workItem.State = nodeDetail.InnerText;

                    }
                    else if (nodeDetail.Name == "confimer")
                    {
                        workItem.Confimer = nodeDetail.InnerText;
                    }
                    else if (nodeDetail.Name == "confimeday")
                    {
                        workItem.Confimeday = nodeDetail.InnerText;

                    }
                    else
                    {
                        workItem.Updateday = nodeDetail.InnerText;
                    }


                }

                list.Add(workItem);
            }

            return list;
        }



        public void Write(List<WorkItem> list)
        {

            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load("d:\\test\\2.xml");//加载xml文件
            //  XmlNode memberlist = xmldoc.SelectSingleNode();
            var root = xmldoc.DocumentElement;//取到根节点
            XmlElement node = (XmlElement)xmldoc.SelectSingleNode("WorkItem/priority");
                node.SetAttribute(null,list[0].Priority);
                xmldoc.Save("d:\\test\\3.xml");
        }

    }

}
