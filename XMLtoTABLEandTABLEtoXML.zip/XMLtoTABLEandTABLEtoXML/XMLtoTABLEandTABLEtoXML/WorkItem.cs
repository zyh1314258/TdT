﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XMLtoTABLEandTABLEtoXML
{
    class WorkItem
    {
      public  string Priority;
      public string Classification;
      public string Detail;
      public string Method;
      public string Enclosure;
      public string Logger;
        
      public string FinishTime;
      public string Maker;
      public string State;
      public string Confimer;
      public string Confimeday;
      public string Updateday;



    }
}
