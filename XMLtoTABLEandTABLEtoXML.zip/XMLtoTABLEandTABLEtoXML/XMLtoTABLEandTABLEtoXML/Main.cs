﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.ComponentModel;
using System.Xml.Serialization;


namespace XMLtoTABLEandTABLEtoXML
{
    public partial class Main : Form
    {
        string xml_FilePath = "";//用来记录当前打开文件的路径的
        DataSet ds = new DataSet();

        public Main()
        {
            InitializeComponent();
        }



        //打开一个xml文件
        private void OpenBtn_Click(object sender, EventArgs e)
        {
            WorkFile f = new WorkFile();
            List<WorkItem> p = f.Read("d:\\test\\2.xml");//调用
            //Read(string d:\\test\\2.xml);
           
            if (dataGridView1.Rows.Count == 1)
            {
               // for (int i = 0; i < 13; i++)
               //{
                    //dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
                int maxCount = p.Count();
                //DataGridViewRow Row = new DataGridViewRow();
                //int index = dataGridView1.Rows.Add(Row);
                for (int index = 0; index < maxCount; index++ )
                {
                    DataGridViewRow Row = new DataGridViewRow();
                    dataGridView1.Rows.Add(Row);
                    dataGridView1.Rows[index].Cells[0].Value = p[index].Priority;
                    dataGridView1.Rows[index].Cells[1].Value = p[index].Classification;
                    dataGridView1.Rows[index].Cells[2].Value = p[index].Detail;
                    dataGridView1.Rows[index].Cells[3].Value = p[index].Method;
                    dataGridView1.Rows[index].Cells[4].Value = p[index].Enclosure;
                    dataGridView1.Rows[index].Cells[5].Value = p[index].Logger;
                    dataGridView1.Rows[index].Cells[6].Value = p[index].FinishTime;
                    dataGridView1.Rows[index].Cells[7].Value = p[index].Maker;
                    dataGridView1.Rows[index].Cells[8].Value = p[index].State;
                    dataGridView1.Rows[index].Cells[9].Value = p[index].Confimer;
                    dataGridView1.Rows[index].Cells[10].Value = p[index].Confimeday;
                    dataGridView1.Rows[index].Cells[11].Value = p[index].Updateday;
                }
                
               }
              // int index = dataGridView1.Rows.Add();
              // dataGridView1.Rows[index].Cells[0].Value = p[0].Priority;
            //}

            
      
        }

        
        //保存xml文件
        private void SaveBtn_Click(object sender, EventArgs e)
        {
            //将datagridview中的数据保存在数组中

            List<WorkItem> list = new List<WorkItem>();
            // List<string> list = new List<string>();
           
                for (int index = 0; index < dataGridView1.Rows.Count; index++)
                {

                    WorkItem workItem = new WorkItem();//给每一行创建对象

                    workItem.Priority = dataGridView1.Rows[index].Cells[1].Value.ToString();
                    workItem.Classification = dataGridView1.Rows[index].Cells[1].Value.ToString();
                    workItem.Detail = dataGridView1.Rows[index].Cells[2].Value.ToString();
                    workItem.Method = dataGridView1.Rows[index].Cells[3].Value.ToString();
                    workItem.Enclosure = dataGridView1.Rows[index].Cells[4].Value.ToString();
                    workItem.Logger = dataGridView1.Rows[index].Cells[5].Value.ToString();
                    workItem.FinishTime = dataGridView1.Rows[index].Cells[6].Value.ToString();
                    workItem.Maker = dataGridView1.Rows[index].Cells[7].Value.ToString();
                    workItem.State = dataGridView1.Rows[index].Cells[8].Value.ToString();
                    workItem.Confimer = dataGridView1.Rows[index].Cells[9].Value.ToString();
                    workItem.Confimeday = dataGridView1.Rows[index].Cells[10].Value.ToString();
                    workItem.Updateday = dataGridView1.Rows[index].Cells[11].Value.ToString();

                  // list.Add(workItem);

                list.Add(workItem);
                //  MessageBox.Show("Insert a valid number!", "Error");


                 WorkFile f = new WorkFile();
                 f.Write(list);
            }
                
        }
    
      

        

        //添加一行
        private void AddBtn_Click(object sender, EventArgs e)
        {
          //  ds.Tables[0].Rows.Add();
           // dataGridView1.DataSource;
        }

       
        //删除一行
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                ds.Tables[0].Rows.RemoveAt(Convert.ToInt32(textBox1.Text) - 1);
            }
            catch
            {
                MessageBox.Show("Insert a valid number!", "Error");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
